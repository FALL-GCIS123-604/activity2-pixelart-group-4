import turtle

pixel_size = int(input("Enter the size of your pixels: "))

def get_color(char):
    color_code = {
        '0': 'black', '1': 'white', '2': 'red', '3': 'yellow',
        '4': 'orange', '5': 'green', '6': 'yellowgreen', '7': 'sienna',
        '8': 'tan', '9': 'gray', 'A': 'darkgray'
    }
    return color_code.get(char, None)

def draw_color_pixel(color_string, turta):
    """
    Draws a single pixel of a specific color
    """
    turta.color(color_string)
    turta.begin_fill()
    for _ in range(4):
        turta.forward(pixel_size)
        turta.right(90)
    turta.end_fill()

def draw_pixel(char, turta):
    """
    Draws a pixel based on the color code
    Uses the draw_color_pixel() function ONLY for valid colors.
    """
    color = get_color(char)
    if color:
        draw_color_pixel(color, turta)
    else:
        print(f"Invalid color for character: {char}")

def draw_line_from_string(color_string, turta):
    """
    Draws a line of pixels corresponding to each character in the input string
    Returns False and stops drawing if an invalid character is given
    """
    for char in color_string:
        color = get_color(char)
        if color is None:
            print(f"Invalid color encountered: {char}")
            return False
        draw_pixel(char, turta)
        turta.forward(pixel_size)
    return True

def draw_shape_from_string(turta):
    """
    Continuously prompts the user to enter color strings and draws a row of pixels
    Stops if an invalid color is entered or if the input is empty
    """
    start_x, start_y = turta.position()
    while True:
        user_input = input("Enter a string of color codes (or an empty string to quit): ")
        if not user_input:
            break
        if not draw_line_from_string(user_input, turta):
            print("Stopped due to an invalid color.")
            break
        turta.penup()
        turta.goto(start_x, turta.ycor() - pixel_size)
        turta.pendown()

def draw_grid_lines(turta, width, height):
    """
    Draws grid lines across the canvas.
    """
    turta.color('black')  # Light color for grid lines
    turta.pensize(2)
    
    # Draw vertical lines
    for x in range(-width // 2, width // 2 + pixel_size, pixel_size):
        turta.penup()
        turta.goto(x, height // 2)
        turta.pendown()
        turta.goto(x, -height // 2)
    
    # Draw horizontal lines
    for y in range(-height // 2, height // 2 + pixel_size, pixel_size):
        turta.penup()
        turta.goto(-width // 2, y)
        turta.pendown()
        turta.goto(width // 2, y)

def center_turtle_for_file(turta, file_path):
    """
    Centers the turtle based on the number of rows and columns in the file.
    """
    try:
        with open(file_path, 'r') as file:
            lines = [line.strip() for line in file if line.strip()]
            num_rows = len(lines)
            num_cols = max(len(line) for line in lines) if lines else 0
            drawing_width = num_cols * pixel_size
            drawing_height = num_rows * pixel_size
            start_x = -drawing_width // 2
            start_y = drawing_height // 2
            turta.penup()
            turta.goto(start_x, start_y)
            turta.pendown()
        return lines
    except FileNotFoundError:
        print("File not found. Please check the path and try again.")
        return None

def draw_shape_from_file(turta):
    """
    Prompts the user for a file path, reads the content, and draws a shape
    """
    file_path = input("Enter the path of the file to read its content: ")
    lines = center_turtle_for_file(turta, file_path)
    if lines is None:
        return
    
    # Reset turtle position to the center of the grid for drawing
    start_x = -len(lines[0]) * pixel_size // 2
    start_y = len(lines) * pixel_size // 2
    turta.penup()
    turta.goto(start_x, start_y)
    turta.setheading(0)  # Ensure the turtle faces right

    for line in lines:
        if not draw_line_from_string(line, turta):
            print("Drawing stopped due to an invalid color in the file.")
            break
        turta.penup()
        turta.goto(start_x, turta.ycor() - pixel_size)  # Move to the next row
        turta.pendown()

    # Draw the grid lines after the shape is drawn
    drawing_width = len(lines[0]) * pixel_size
    drawing_height = len(lines) * pixel_size
    draw_grid_lines(turta, drawing_width, drawing_height)

def draw_grid(turta):
    """
    Draws a 20x20 checkerboard
    """
    start_x, start_y = turta.position()
    for row in range(20):
        for col in range(20):
            draw_color_pixel('black' if (row + col) % 2 == 0 else 'red', turta)
            turta.penup()
            turta.forward(pixel_size)
            turta.pendown()
        turta.penup()
        turta.goto(start_x, start_y - pixel_size * (row + 1))
        turta.pendown()

def center_turtle(turta, width, height):
    """
    Centers the turtle on the screen 
    """
    screen_width = turtle.window_width()
    screen_height = turtle.window_height()
    start_x = -width // 2
    start_y = height // 2
    turta.penup()
    turta.goto(start_x, start_y)
    turta.pendown()

def main():
    """
    Main function to execute the program
    """
    screen = turtle.Screen()
    screen.setup(width=800, height=800)
    turta = turtle.Turtle()
    turta.speed(0)

    center_turtle(turta, 400, 400)

    choice = input("Choose an option: 1 - Draw from string, 2 - Draw grid, 3 - Draw from file: ")
    if choice == '1':
        draw_shape_from_string(turta)
    elif choice == '2':
        draw_grid(turta)
    elif choice == '3':
        draw_shape_from_file(turta)
    else:
        print("Invalid choice.")

    screen.mainloop()

if __name__ == "__main__":
    main()
